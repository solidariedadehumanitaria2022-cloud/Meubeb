package com.postestlab.nfc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayAdapter<String> logAdapter;
    private ArrayList<String> logItems=new ArrayList<>();
    private BroadcastReceiver receiver;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        ListView lv=new ListView(this);
        setContentView(lv);
        logAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,logItems);
        lv.setAdapter(logAdapter);
        NfcAdapter nfc=NfcAdapter.getDefaultAdapter(this);
        if(nfc==null) Toast.makeText(this,"NFC não disponível",Toast.LENGTH_LONG).show();
        else if(!nfc.isEnabled()) startActivity(new Intent(Settings.ACTION_NFC_SETTINGS));
        receiver=new BroadcastReceiver(){
            @Override public void onReceive(Context c, Intent i){
                String cmd=i.getStringExtra("command");
                String rsp=i.getStringExtra("response");
                logItems.add(0,"CMD:"+cmd+" -> RSP:"+rsp);
                logAdapter.notifyDataSetChanged();
            }
        };
        registerReceiver(receiver,new IntentFilter(PaymentHCEService.ACTION_APDU_LOG));
    }
    @Override protected void onDestroy(){
        super.onDestroy();
        unregisterReceiver(receiver);
    }
}
