package com.postestlab.nfc;

import android.content.Intent;
import android.content.res.AssetManager;
import android.nfc.cardemulation.HostApduService;
import android.os.Bundle;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PaymentHCEService extends HostApduService {
    public static final String ACTION_APDU_LOG = "com.postestlab.nfc.APDU_LOG";
    private Map<String, String> apduResponses = new HashMap<>();

    @Override
    public void onCreate() {
        super.onCreate();
        loadConfig();
    }

    @Override
    public byte[] processCommandApdu(byte[] commandApdu, Bundle extras) {
        String cmd = bytesToHex(commandApdu);
        String rsp = apduResponses.getOrDefault(cmd, "6F00");
        sendLog(cmd, rsp);
        return hexToBytes(rsp);
    }

    @Override
    public void onDeactivated(int reason) {}

    private void loadConfig() {
        try {
            AssetManager am = getAssets();
            InputStream is = am.open("pos-testlab-config-1757859618709.json");
            String jsonStr = new Scanner(is, StandardCharsets.UTF_8.name()).useDelimiter("\A").next();
            JSONObject cfg = new JSONObject(jsonStr);
            JSONArray txs = cfg.getJSONObject("testData").getJSONArray("sampleTransactions");
            for (int i=0;i<txs.length();i++) {
                JSONArray apdus = txs.getJSONObject(i).getJSONArray("expectedAPDU");
                for (int j=0;j<apdus.length();j++) {
                    apduResponses.put(apdus.getString(j), "9000");
                }
            }
        } catch(Exception e){ Log.e("PaymentHCEService","Erro cfg",e); }
    }

    private void sendLog(String cmd,String rsp){
        Intent it=new Intent(ACTION_APDU_LOG);
        it.putExtra("command",cmd);
        it.putExtra("response",rsp);
        sendBroadcast(it);
    }

    private String bytesToHex(byte[] b){
        StringBuilder sb=new StringBuilder();
        for(byte x:b) sb.append(String.format("%02X",x));
        return sb.toString();
    }
    private byte[] hexToBytes(String s){
        int len=s.length();
        byte[] d=new byte[len/2];
        for(int i=0;i<len;i+=2)
            d[i/2]=(byte)((Character.digit(s.charAt(i),16)<<4)+Character.digit(s.charAt(i+1),16));
        return d;
    }
}
